<template>
  <div>
    No content on this page
  </div>
</template>

<script>
export default {
  name: 'notfound'
}
</script>
